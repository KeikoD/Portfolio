import java.sql.*;
import java.util.*;
import java.io.Console;
import java.io.IOException;
import java.nio.file.*;

//Eden Dronoff with original code by Kathryn Lenth
//Connects to DrawingBoard SQL database
public class DrawingBoard implements AutoCloseable {
	Scanner in = new Scanner(System.in);
	String answer = "";
	String username = "";

	// Keeps track of the chosen query
	public int requestChange = 0;

	// Default connection information (most can be overridden with command-line arguments)
	private static final String DB_NAME = "ekd1109_drawingBoard";
	private static final String DB_USER = "token_dcac";
	private static final String DB_PASSWORD = "eEwgcOgeI3oRJvop";

	// The queries that can be executed

	private final String QUERYB = 
			"INSERT INTO `User` (name)\n" + 
					" VALUES ('" + username + "')\n";

	// Connection information to use
	private final String dbHost;
	private final int dbPort;
	private final String dbName;
	private final String dbUser, dbPassword;

	// The database connection and prepared statement (query)
	private Connection connection;
	private PreparedStatement query;

	/**
	 * Creates an {@code IMDbEpisodeQuery} with the specified connection information.
	 * @param sshKeyfile the filename of the private key to use for ssh
	 * @param dbName the name of the database to use
	 * @param dbUser the username to use when connecting
	 * @param dbPassword the password to use when connecting
	 * @throws SQLException if unable to connect
	 */
	public DrawingBoard(String dbHost, int dbPort, String dbName,
			String dbUser, String dbPassword) throws SQLException {
		this.dbHost = dbHost;
		this.dbPort = dbPort;
		this.dbName = dbName;
		this.dbUser = dbUser;
		this.dbPassword = dbPassword;

		System.out.println("Hello! Would you like to login or create an account?:\n"
				+ "A: Login\n"
				+ "B: Create an account\n"
				+ "C: Nevermind\n");

		String line = in.nextLine();
		if(line.equalsIgnoreCase("a")  || line.equalsIgnoreCase("b")){
			connect(line);
		}
		else {
			System.out.println("Bye then!");
		}

	}

	private void connect(String query) throws SQLException {
		// URL for connecting to the database: includes host, port, database name,
		// user, password
		final String url = String.format("jdbc:mysql://%s:%d/%s?user=%s&password=%s",
				dbHost, dbPort, dbName,
				dbUser, dbPassword
				);

		// Attempt to connect, returning a Connection object if successful
		this.connection = DriverManager.getConnection(url);

		// Prepare the statement (query) that we will execute
		if (query.equalsIgnoreCase("a")) {
			byte[] userId = null;
			System.out.println("Please enter in your username (Case Sensitive)");
			username = in.nextLine();
			final String QUERYA = 
					"SELECT id\n" 
							+ "FROM `User`\n"
							+ "WHERE name = '" + username + "'\n";

			var statement = connection.prepareStatement(QUERYA);
			var results = statement.executeQuery();
			while (results.next())
				userId = results.getBytes("id");

			// If there were no matching username/passwords, then exit.
			if (userId == null) {
				System.out.println("Invalid username");
				System.exit(0);
			}
		}
		else if (query.equalsIgnoreCase("b")){
			while (true) {
				int usernm = 0;
				System.out.println("Welcome new user!");
				System.out.println("Please enter a username and be sure to remember it!");
				username = in.nextLine();
				//check is the username already exists
				final String CHECK = 
						"SELECT id\n" 
								+ "FROM User\n"
								+ "WHERE name = '" + username + "'\n";
				var statement = connection.prepareStatement(CHECK);
				var results = statement.executeQuery();
				while (results.next())
					usernm = results.getInt("id");
				if (usernm > 0) {
					System.out.println("That username is taken! Try again");
				}
				else {
					break;
				}
			}		
			var statement = connection.prepareStatement(QUERYB);
			statement.execute();

			System.out.println("Nice Name!");
			
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

			newUser(username);
		}
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

		idea(username);
	}

	//contains the code for interacting with the User table as a new user
	public void newUser(String name) throws SQLException {
		System.out.println("Would you like to add any new information about yourself?\n"
				+ "A: Description\n"
				+ "B: Pronouns\n"
				+ "C: No. Send me to the ideas\n");
		answer = in.nextLine();
		if(answer.equalsIgnoreCase("a")) {
			System.out.println("Tell us about yourself! You can type up to 100 letters");
			answer = in.nextLine();
			final String QUERYDES = 
					"UPDATE User\n" 
							+ "SET description = '" + answer + "'\n"
							+ "WHERE name = '" + name + "'\n";

			var statement = connection.prepareStatement(QUERYDES);
			statement.execute();
		}            
		else if(answer.equalsIgnoreCase("b")) {
			System.out.println("Tell us about yourself! You can type up to 100 letters");
			answer = in.nextLine();
			final String QUERYPRO = 
					"UPDATE User\n" 
							+ "SET pronouns = '" + answer + "'\n"
							+ "WHERE name = '" + name + "'\n";

			var statement = connection.prepareStatement(QUERYPRO);
			statement.execute();
		}
		else if(answer.equalsIgnoreCase("c")){
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

			idea(name);
		}
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

		newUser(name);
	}

	//contains the code for interacting with the Idea table
	public void idea(String name) throws SQLException {
		System.out.print("Do you have an idea?\n"
				+ "A: Create an idea\n"
				+ "B: View my ideas\n"
				+ "C: View all user ideas\n"
				+ "D: None of the above");
		answer = in.nextLine();

		if(answer.equalsIgnoreCase("a")) {
			System.out.println("Great! Tell me about it!");
			answer = in.nextLine();
			final String QUERYID = 
					"INSERT INTO Idea (userId,description)\n" 
							+ "VALUES ((\n"
							+ "SELECT id\n"
							+ "FROM User\n"
							+ "WHERE name = '" + name + "')\n"
							+ ",'" + answer + "')\n";
			/*final String QUERYID2 =
					"INSERT INTO `works on` (userId,projectId)\n"
							+ "VALUES((\n"
							+ "SELECT id\n"  
							+ "FROM User\n"  
							+ "WHERE name = '" + name + "')\n" 
							+ ",3)\n"; 
			var statement2 = connection.prepareStatement(QUERYID2);
			statement2.execute(); */
			var statement = connection.prepareStatement(QUERYID);
			statement.execute();
		}            
		else if(answer.equalsIgnoreCase("b")) {
			System.out.println("Here are your ideas");
			final String QUERYID2 = 
					"SELECT description,dateCreated\n"
							+ "FROM Idea\n"
							+ "WHERE userId = (\n"
							+ "SELECT id\n"
							+ "FROM User\n"
							+ "WHERE name = '" + name + "')\n"
							+ "ORDER BY id\n";

			var statement = connection.prepareStatement(QUERYID2);
			var results = statement.executeQuery();
			while (results.next()) {
				var description = results.getString("description");
				var date = results.getDate("dateCreated");
				date.toString();
				System.out.printf("'%s' was created on %s\n", description, date);
			}
			System.out.println("");
		}
		else if(answer.equalsIgnoreCase("c")) {
			System.out.println("Here are everyone's ideas");
			final String QUERYID3 = 
					"SELECT Idea.description,Idea.dateCreated,User.name\n"
							+ "FROM Idea\n"
							+ "INNER JOIN User ON Idea.userId = User.id\n"
							+ "ORDER BY User.id\n";	
			var statement = connection.prepareStatement(QUERYID3);
			var results = statement.executeQuery();
			while (results.next()) {
				var description = results.getString("description");
				var date = results.getDate("dateCreated");
				date.toString();
				var user = results.getString("name");
				System.out.printf("'%s' was created on %s by %s\n", description, date, user);
			}
			System.out.println("");

		}
		else if(answer.equalsIgnoreCase("d")) {
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

			System.out.print("What would you like to do ?\n"
					+ "A: Look at the ideas\n"
					+ "B: Add something to my user profile\n"
					+ "C: Look at the mediums\n"
					+ "D: Leave");
			answer = in.nextLine();
			if(answer.equalsIgnoreCase("a")) {
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

				idea(name);
			}            
			else if(answer.equalsIgnoreCase("b")) {
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

				newUser(name);
			}
			else if(answer.equalsIgnoreCase("d")) {
				System.exit(0);
			}
			else if(answer.equalsIgnoreCase("c")){
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

				medium(name);
			}
		}
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

		idea(name);
	}
	//contains the code for interacting with the Medium table
	public void medium(String name) throws SQLException{
		System.out.println("Here are the mediums currently in the database\n");
		final String QUERYPRO3 = 
				"SELECT name,definition\n"
						+ "FROM Medium\n"
						+ "ORDER BY id\n";
		var statement = connection.prepareStatement(QUERYPRO3);
		var results = statement.executeQuery();
		while (results.next()) {
			var proname = results.getString("name");
			var defin = results.getString("definition");
			System.out.println(proname + ": " + defin);
		}
		System.out.println("");

		System.out.println("Would you like to make an addition?\n"
				+ "Yes\n"
				+ "No");
		answer = in.nextLine();
		if(answer.equalsIgnoreCase("yes")) {
			System.out.println("What is the name of the medium?");
			String medName = in.nextLine();
			System.out.println("Describe it please!");
			String medDes = in.nextLine();
			final String MEDIUMQUERY =
					"INSERT INTO Medium (name,definition)\n"
							+ "VALUES ('" + medName + "','" + medDes + "')\n"; 
			var var = connection.prepareStatement(MEDIUMQUERY);
			var.execute();
		}
		else {
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

			System.out.print("What would you like to do ?\n"
					+ "A: Look at the ideas\n"
					+ "B: Add something to my user profile\n"
					+ "C: Look at the mediums\n"
					+ "D: Leave");
			if(answer.equalsIgnoreCase("a")) {
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

				idea(name);
			}            
			else if(answer.equalsIgnoreCase("b")) {
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

				newUser(name);
			}
			else if(answer.equalsIgnoreCase("d")) {
				System.exit(0);
			}
			else if(answer.equalsIgnoreCase("c")){
				System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

				medium(name);
			}
		}
		System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~");

		medium(name);
	}
	/*//contains the code for interacting with the Project table
	public void project(String name) throws SQLException {
		System.out.print("What would you like to do with the projects?\n"
				+ "A: See projects I am in\n"
				+ "B: See all projects\n"
				+ "C: Create a project\n"
				+ "D: None of the above");

		answer = in.nextLine();

		if(answer.equalsIgnoreCase("a")) {
			System.out.println("You are in these projects:");
			final String QUERYPRO = 
					"SELECT Project.name,Project.description,Project.dateCreated,Project.genre,User.name,Medium.name\n"
							+ "FROM 'Project'\n"
							+ "INNER JOIN Medium ON Project.mediumId = Medium.id\n"
							+ "INNER JOIN 'works on' ON Project.id = 'works on'.projectId\n"
							+ "INNER JOIN User ON User.id = 'works on'.userId\n"
							+ "WHERE 'works on'.userId LIKE '%(\n"
							+ "SELECT id\n"
							+ "FROM User\n"
							+ "WHERE name = '" + name + "')%'\n"
							+ "ORDER BY id\n";

			var statement = connection.prepareStatement(QUERYPRO);
			var results = statement.executeQuery();
			while (results.next()) {
				var proname = results.getString("Project.name");
				var description = results.getString("Project.description");
				var date = results.getDate("Project.dateCreated");
				var genre = results.getArray("Project.genre");
				var medName = results.getString("Medium.name");
				var usName = results.getString("User.name");
				System.out.printf("[%04d] %s\n", proname,description,date,usName,genre,medName);
			}
		}            
		else if(answer.equalsIgnoreCase("b")) {
			System.out.println("Here are all the projects:");
			final String QUERYPRO2 = 
					"SELECT Project.name,Project.description,Project.dateCreated,Project.genre,User.name,Medium.name\n"
							+ "FROM 'Project'\n"
							+ "INNER JOIN Medium ON Project.mediumId = Medium.id\n"
							+ "INNER JOIN 'works on' ON Project.id = 'works on'.projectId\n"
							+ "INNER JOIN User ON User.id = 'works on'.userId\n"
							+ "ORDER BY id\n";

			var statement = connection.prepareStatement(QUERYPRO2);
			var results = statement.executeQuery();
			while (results.next()) {
				var proname = results.getString("Project.name");
				var description = results.getString("Project.description");
				var date = results.getDate("Project.dateCreated");
				var genre = results.getArray("Project.genre");
				var medName = results.getString("Medium.name");
				var usName = results.getString("User.name");
				System.out.printf("[%04d] %s\n", proname,description,date,usName,genre,medName);
			}
		}
		else if(answer.equalsIgnoreCase("c")) {
			System.out.println("Let's get started! I need two things first:\n"
					+ "First enter a description for your project");
			String description = in.nextLine();
			final String QUERYPRO3 = 
					"SELECT name\n"
							+ "FROM 'Medium'\n"
							+ "ORDER BY id\n";
			var statement = connection.prepareStatement(QUERYPRO3);
			var results = statement.executeQuery();
			System.out.println("Now a medium for the project! Here are your choices:\n");
			while (results.next()) {
				var proname = results.getString("name");
				System.out.println(proname);
			}
			System.out.println("Type in the medium you want to use or press enter to make a new medium");
			answer = in.nextLine();
			if(answer.isBlank()) {
				System.out.println("What is the name of the medium?");
				String medName = in.nextLine();
				System.out.println("Describe it please!");
				String medDes = in.nextLine();
				final String MEDIUMQUERY =
						"INSERT INTO 'Medium' (name,definition)\n"
								+ "VALUES ('" + medName + "','" + medDes + "')\n"; 
				var var = connection.prepareStatement(MEDIUMQUERY);
				var.execute();

				final String PROJECTQUERY = 
						"INSERT INTO 'Project' (description,projectId)\n" 
								+ "VALUES (" + description + "," + "(\n"
								+ "SELECT id\n"
								+ "FROM Medium\n"
								+ "WHERE name LIKE '" + medName + "')\n"
								+ ")\n";
				var var2 = connection.prepareStatement(PROJECTQUERY);
				var2.execute();
				//System.out.println("Do you want to connect any ideas to this project?");
			}
			else {
				final String PROJECTQUERY = 
						"INSERT INTO 'Project' (description,projectId)\n" 
								+ "VALUES (" + description + "," + "(SELECT id\n"
								+ "FROM Medium\n"
								+ "WHERE name LIKE '" + answer + "')\n"
								+ ")\n";
				var var = connection.prepareStatement(PROJECTQUERY);
				var.execute();
			}
			System.out.println("Now enter a name for the project or press enter to leave it blank");
			answer = in.nextLine();
			if(answer.isBlank() == false) {
				final String PROJECTQUERY2 = 
						"INSERT INTO 'Project' (name)\n" 
								+ "VALUES ('" + answer + "')\n"
								+ "WHERE description = '" + description + "'\n";
				var var = connection.prepareStatement(PROJECTQUERY2);
				var.execute();
			}
		}
		else if(answer.equalsIgnoreCase("d")) {
			System.out.print("What would you like to do ?\n"
					+ "A: Look at the ideas\n"
					+ "B: Add something to my user profile\n"
					+ "C: Nevermind. Back to the projects\n"
					+ "D: Leave");
			if(answer.equalsIgnoreCase("a")) {
				idea(name);
			}            
			else if(answer.equalsIgnoreCase("b")) {
				newUser(name);
			}
			else if(answer.equalsIgnoreCase("c")) {
				project(name);
			}
			else if(answer.equalsIgnoreCase("d")) {
				System.exit(0);
			}
		}
		else {
			System.exit(0);
		}
	}
	 */
	/**
	 * Closes the connection to the database.
	 */
	@Override
	public void close() throws SQLException {
		connection.close();
	}

	/**
	 * Entry point of the application. Uses command-line parameters to override database
	 * connection settings, then invokes runApp().
	 */
	public static void main(String... args) {
		// Default connection parameters (can be overridden on command line)
		Map<String, String> params = new HashMap<>(Map.of(
				"dbname", "" + DB_NAME,
				"user", DB_USER,
				"password", DB_PASSWORD
				));

		boolean printHelp = false;

		// Parse command-line arguments, overriding values in params
		for (int i = 0; i < args.length && !printHelp; ++i) {
			String arg = args[i];
			boolean isLast = (i + 1 == args.length);

			switch (arg) {
			case "-h":
			case "-help":
				printHelp = true;
				break;

			case "-dbname":
			case "-user":
			case "-password":
				if (isLast)
					printHelp = true;
				else
					params.put(arg.substring(1), args[++i]);
				break;

			default:
				System.err.println("Unrecognized option: " + arg);
				printHelp = true;
			}
		}

		// If help was requested, print it and exit
		if (printHelp) {
			printHelp();
			return;
		}

		// Connect to the database. This use of "try" ensures that the database connection
		// is closed, even if an exception occurs while running the app.
		try (DatabaseTunnel tunnel = new DatabaseTunnel();
				DrawingBoard app = new DrawingBoard(
						"localhost", tunnel.getForwardedPort(), params.get("dbname"),
						params.get("user"), params.get("password")
						)) {

		} catch (IOException ex) {
			System.err.println("Error setting up ssh tunnel.");
			ex.printStackTrace();
		} catch (SQLException ex) {
			System.err.println("Error communicating with the database (see full message below).");
			ex.printStackTrace();
			System.err.println("\nParameters used to connect to the database:");
			System.err.printf("\tSSH keyfile: %s\n\tDatabase name: %s\n\tUser: %s\n\tPassword: %s\n\n",
					params.get("sshkeyfile"), params.get("dbname"),
					params.get("user"), params.get("password")
					);
			System.err.println("(Is the MySQL connector .jar in the CLASSPATH?)");
			System.err.println("(Are the username and password correct?)");
		}

	}

	private static void printHelp() {
		System.out.println("Accepted command-line arguments:");
		System.out.println();
		System.out.println("\t-help, -h          display this help text");
		System.out.println("\t-dbname <text>     override name of database to connect to");
		System.out.printf( "\t                   (default: %s)\n", DB_NAME);
		System.out.println("\t-user <text>       override database user");
		System.out.printf( "\t                   (default: %s)\n", DB_USER);
		System.out.println("\t-password <text>   override database password");
		System.out.println();
	}

}
