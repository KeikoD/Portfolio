public class SimpleHoldPlayerDemo {
    public static void main(String[] args) {
      SimpleHoldPlayer player = new SimpleHoldPlayer("simple hold");
      player.addPoints(30);
      int accumulated = 0;
      boolean answer;
      do {            
         accumulated += 3;  // rolls 3 every time
         System.out.println("turn total is " + accumulated);
         answer = player.isRolling(accumulated, 35);
      } while (answer);
      System.out.println("done, stopped at " + accumulated); 
   }
}
