//Eden Dronoff
import java.util.Scanner;
/**A two-player dice game where players will accumulate points during their turn, until they cede their turn and bank the points. The first player that reaches a certain number of points (the goal) wins the gam
*/
public class PigGame {
   public static final int GOAL = 100;  //make sure is 100 at the end
   private PigPlayer Player1;
   private PigPlayer Player2;
   public static boolean verbose=false;
     /** Constructor that two players
     */
   public PigGame(){
      Player1=new SimpleHoldPlayer();
      Player2=new SimpleHoldPlayer();
   }
   /** Constructor that takes two Strings 
   */
   public PigGame(String First, String Second){ 
      Player1=new SimpleHoldPlayer();
      Player2=new SimpleHoldPlayer();
      Player1.setName(First);
      Player2.setName(Second);
      //Player1=new SimpleHoldPlayer(First);
      
   }
   /** Constructor that takes two PigPlayers 
   */
   public PigGame(PigPlayer One, PigPlayer Two) {
      Player1=One;
      Player2=Two;
   }
     /**Resets the two Players for a new game 
     */
   public void reset(){
      Player1.reset();
      Player2.reset();
   }
   /**Rolls the die and returns the turn total
   */
   public static int playTurn(PigPlayer player, PigPlayer opponent) {
      int turnTotal=0;
      do {
         int score = Die.roll();
         if (score>1){
            if (verbose) {
               System.out.println("You rolled a: " + score);
            }
            turnTotal=(turnTotal + score);
         }
         else {
            turnTotal=0;
            if (verbose) {
               System.out.println("You rolled a: 1");
               System.out.println("Your turn is over");
            }
            break;
         }
      } while (player.isRolling(turnTotal,opponent.getScore()) == true);
      if (verbose) {
         System.out.println("");
      }
      player.addPoints(turnTotal);
      return turnTotal;
   }
   /**Plays an entire game of Pig
   */
   public void playGame(){
      while (Player1.won()==false && Player2.won()==false){
         if (verbose) {
            System.out.println(Player1.getName() + "'s score: " + Player1.getScore());
            System.out.println(Player2.getName() + "'s score: " + Player2.getScore());
            System.out.println("");
            System.out.println("It is " + Player1.getName() + "'s turn");
         }
         PigGame.playTurn(Player1,Player2); 
         if (Player1.won() == false){
            if (verbose) {
               System.out.println(Player1.getName() + "'s score: " + Player1.getScore());
               System.out.println(Player2.getName() + "'s score: " + Player2.getScore());
               System.out.println("");
               System.out.println("It is " + Player2.getName() + "'s turn");
            }
            PigGame.playTurn(Player2,Player1);
         }
      }
      if (Player1.won() == true){
         if (verbose) {
            System.out.println(Player1.getName() + " won! Congratulations!");
         }
      }
      else if (Player2.won() == true){
         if (verbose) {
            System.out.println(Player2.getName() + " won! Congratulations!");
         }
      }
      if (verbose) {
         System.out.println(Player1.getName() + "'s score: " + Player1.getScore());
         System.out.println(Player2.getName() + "'s score: " + Player2.getScore());
      }
   }
   /**Print the rules and prompt the users for their names
   */
   public static void userVsUser(){
      Scanner scnr = new Scanner(System.in);  
      if (verbose) {
         System.out.println("Pig Game Start!");
         System.out.println("How to play:");
         System.out.println("    Two players race to gain 100 points first");
         System.out.println("    Points are earned by rolling a die until you stop, or roll a 1, in which your current points gained in the turn are reset to 0");
         System.out.println("    When it is your turn, press enter to roll and type anything to hold");
         System.out.println("");
         System.out.println("Please enter Player 1's name");
      }
      PigPlayer PlayerOne= new UserPigPlayer(scnr.nextLine());
      if (verbose) {
         System.out.println("Please enter Player 2's name");
      }
      PigPlayer PlayerTwo= new UserPigPlayer(scnr.nextLine());
      if (verbose) {
         System.out.println(""); 
      }
      int result = (int)(Math.random()*2); 
      if (result == 1) {
         PigGame game = new PigGame(PlayerOne, PlayerTwo);
         game.playGame();
      }
      else {
         PigGame game = new PigGame(PlayerTwo,PlayerOne);
         game.playGame();
      }
   }
   /**Allows the user to play against the computer
   */
   public static void userVsComputer() {
      Scanner scnr = new Scanner(System.in); 
      if (verbose) {
         System.out.println("Pig Game Start!");
         System.out.println("How to play:");
         System.out.println("    Two players race to gain 100 points first");
         System.out.println("    Points are earned by rolling a die until you stop, or roll a 1, in which your current points gained in the turn are reset to 0");
         System.out.println("    When it is your turn, press enter to roll and type anything to hold");
         System.out.println("");
         System.out.println("Please enter the user's name");
      }
      PigPlayer playerUser= new UserPigPlayer(scnr.nextLine());
      PigPlayer computer= new FourTurnsPlayer();
      int result = (int)(Math.random()*2); 
      if (result == 1) {
         PigGame game = new PigGame(playerUser, computer);
         game.playGame();
      }
      else {
         PigGame game = new PigGame(computer,playerUser);
         game.playGame();
      }
   }
   /**plays the computer against itself
   */
   public static void computerVsComputer(){
      PigGame game = new PigGame("Computer 1", "Computer 2");
      game.playGame();
   }
   //Main method
   public static void main(String[] args){
      userVsComputer();
   }
}