public class UserPigPlayerDemo {
   public static void main(String[] args) {
      UserPigPlayer player = new UserPigPlayer("test player");
      int accumulated = 0;
      boolean answer;
      do {
         accumulated += 5;  // rolls 5 every time
         answer = player.isRolling(accumulated, 35);
      } while (answer);
      System.out.println("done");      
   }
}
