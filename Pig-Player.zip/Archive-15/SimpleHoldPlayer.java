//Eden Dronoff
/**A computer player that uses a strategy to roll until a value is reached 
*/
public class SimpleHoldPlayer extends PigPlayer{
   public int hold;
   /**Constructor that sets the hold value to 20
   */
   public SimpleHoldPlayer(){
      super("SimpleHoldPlayer");
      hold=20;
   }
   /**Constructor that takes the player name
   */
   public SimpleHoldPlayer(String name){
      super(name);
      hold=20;
   }
   /**Constructor that takes the player name and sets the hold value to inputed value
   */
   public SimpleHoldPlayer(String name, int hold){
      super(name);
      if (hold<1){
         hold=20;
      }
      else{
         this.hold=hold;
      }
   }
   /**The player's strategy. It will roll according to the designated hold value
   */
   public boolean isRolling(int turnTotal, int opponentScore){
      if (turnTotal<hold && this.getScore()+turnTotal<PigGame.GOAL){ 
         return true;
      }
      else {
         return false;
      }
   }

}