public class FourTurnsPlayerTest extends PigPlayerTest{
 // not a real progression, because addPoints never gets called
   public void testFourTurnsNotReal() {
      FourTurnsPlayer player = new FourTurnsPlayer();
   // 0 holds
      assertTrue(player.isRolling(24, 0));
      assertFalse(player.isRolling(25, 0));
   
   // 1 hold
      assertTrue(player.isRolling(32, 0));
      assertFalse(player.isRolling(33, 0));
   
   // 2 holds
      assertTrue(player.isRolling(49, 0));
      assertFalse(player.isRolling(50, 0));
   
   // 3 holds
      assertTrue(player.isRolling(99, 0));
      assertFalse(player.isRolling(100, 0));
   
   }
 
 // Now following the score progression that would happen normally...
   public void testFourTurnsReal() {
      FourTurnsPlayer player = new FourTurnsPlayer();
   
   // 0 holds
      assertTrue(player.isRolling(24, 0));
      assertFalse(player.isRolling(27, 0));
   
      player.addPoints(27);
   // 1 hold, score 27. Hold value should be 24.
      assertTrue(player.isRolling(23, 0));
      assertFalse(player.isRolling(24, 0));
   
      player.addPoints(24);
   // 2 holds, score 51. Hold value should be 24 again.
      assertTrue(player.isRolling(23, 0));
      assertFalse(player.isRolling(24, 0));
   
      player.addPoints(24);
   
   // 3 holds, score 75. Hold value should be 25.
      assertTrue(player.isRolling(24, 0));
      assertFalse(player.isRolling(25, 0));
   
   // Player should have won after this point.
      player.addPoints(25);
      assertTrue(player.won());
   }
 
 // checking that reset works
   public void testFourTurnsReset() {
      FourTurnsPlayer player = new FourTurnsPlayer();
   
   // 0 turns
      assertTrue(player.isRolling(24, 0));
      assertFalse(player.isRolling(27, 0));
   
      player.addPoints(27);
   // 1 turn, score 27. Hold value should be 24.
      assertTrue(player.isRolling(23, 0));
      assertFalse(player.isRolling(24, 0));
   
      player.addPoints(24);
   // 2 turns, score 51. Hold value should be 24 again.
      assertTrue(player.isRolling(23, 0));
      assertFalse(player.isRolling(24, 0));
   
      player.addPoints(19);
   
   // 3 turns, score 70. Hold value should be 30.
      assertTrue(player.isRolling(29, 0));
      assertFalse(player.isRolling(30, 0));
   
   // Player should have won after this point.
      player.reset();
   
   // hold value should be back to 25
      assertTrue(player.isRolling(24, 0));
      assertFalse(player.isRolling(25, 0));
   }
 
}
