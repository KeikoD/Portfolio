//Eden Dronoff
/**A computer player that tries to win in 4 turns 
*/
public class FourTurnsPlayer extends PigPlayer{
   private int holdTurn=4;
   private int holdValue=25;
   /**Constructor that creates a FourTurnsPlayer and sets the holdValue
   **/
   public FourTurnsPlayer(){
      super("FourTurnsPlayer");
      holdValue=(PigGame.GOAL/holdTurn);
   }
   /**Constructor that creates a FourTurnsPlayer with a name and sets the holdValue
   **/
   public FourTurnsPlayer(String name){
      super(name);
      holdValue=(PigGame.GOAL/holdTurn);
   }
   /**The player's strategy. It will roll according to the designated hold value
   */
   public boolean isRolling(int turnTotal, int opponentScore){
      if (this.getScore()+turnTotal<PigGame.GOAL && turnTotal<holdValue){ 
         holdValue=((PigGame.GOAL-this.getScore())/holdTurn);
         return true;
      }
      else {
         holdTurn--;
         if (holdTurn==0){
            holdTurn=4;
         }
         else {
            holdValue=((PigGame.GOAL-this.getScore())/holdTurn);
         }
         return false;
      } 
   }
}