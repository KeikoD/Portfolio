import junit.framework.TestCase;
import static junit.framework.Assert.*;

public class DieTest extends TestCase {

   public void testDefaultConstructor() {
      Die basic = new Die();
      assertEquals(6, basic.getNumberOfSides());
   }
   
   public void testSecondConstructor() {
      Die complex = new Die(13);
      assertEquals(13, complex.getNumberOfSides());
      
      Die coin = new Die(2);
      assertEquals(2, coin.getNumberOfSides());
   
      Die boring = new Die(1);
      assertEquals(1, boring.getNumberOfSides());
   }
         
/**                                                                                                  
   * test the mutator rejects invalid sides                                                            
   */
   public void testInvalidSides() {
      Die invalid = new Die(-1);
      assertFalse(invalid.getNumberOfSides() == -1);
   
      Die negative = new Die(-5);
      assertFalse(negative.getNumberOfSides() == -5);
      
      Die zero = new Die(0);
      assertFalse(zero.getNumberOfSides() == -5);
   }
   
   public void testRecoverConstructors(){
      // zero not allowed - should create six-sided die
      Die zero = new Die(0);
      assertEquals(6, zero.getNumberOfSides());
   
      Die negative = new Die(-5);
      assertEquals(6, negative.getNumberOfSides());
   }  


   public void testBasicRoll() {
      Die basic = new Die();
      int[] count = {0,0,0,0,0,0};
      for (int i=0; i<10000; i++) {
         int num = basic.rollDie();
         assertTrue(1 <= num && num <= 6);
         count[num-1]++;
      }
      for (int i=0; i<count.length; i++) {
         assertTrue(1500 <= count[i] && count[i] <= 1875);
      // use this to debug
      // System.out.println("unexpected number of rolls of "+(i+1) + ": " + count[i]);
      }
   }  
   
   public void testComplexRoll() {
      Die complex = new Die(13);
      int[] count = {0,0,0,0,0,0,0,0,0,0,0,0,0};
      for (int i=0; i<1300; i++) {
         int num = complex.rollDie();
         assertTrue(1 <= num && num <= 13);
         count[num-1]++;
      }
      for (int i=0; i<count.length; i++) {
         assertTrue(50 <= count[i] && count[i] <= 150);
      // use this to debug
      // System.out.println("unexpected number of rolls of "+(i+1) + ": " + count[i]);
      }
   }  

   // should create a regular six-sided die
   public void testZeroRoll() {
      Die basic = new Die(0);
      int[] count = {0,0,0,0,0,0};
      for (int i=0; i<10000; i++) {
         int num = basic.rollDie();
         assertTrue(1 <= num && num <= 6);
         count[num-1]++;
      }
      for (int i=0; i<count.length; i++) {
         assertTrue(1500 <= count[i] && count[i] <= 1875);
      // use this to debug
      // System.out.println("unexpected number of rolls of "+(i+1) + ": " + count[i]);
      }
   }  
   
    // testing public static int roll()
   public void testStaticRoll1() {
      int[] count = {0,0,0,0,0,0};
      for (int i=0; i<10000; i++) {
         int num = Die.roll();
         assertTrue(1 <= num && num <= 6);
         count[num-1]++;
      }
      for (int i=0; i<count.length; i++) {
         assertTrue(1500 <= count[i] && count[i] <= 1875);
      // use this to debug
      // System.out.println("unexpected number of rolls of "+(i+1) + ": " + count[i]);
      }
   }  
   
    // testing public static int roll(int sides)
   public void testStaticRoll2() {
      int[] count = {0,0,0,0,0,0,0,0,0,0,0,0,0};
      for (int i=0; i<1300; i++) {
         int num = Die.roll(13);
         assertTrue(1 <= num && num <= 13);
         count[num-1]++;
      }
      for (int i=0; i<count.length; i++) {
         assertTrue(50 <= count[i] && count[i] <= 150);
      // use this to debug
      // System.out.println("unexpected number of rolls of "+(i+1) + ": " + count[i]);
      }
   }
   
   // if an invalid value, always roll 1
   public void testStaticRollZero() {
      for (int i=0; i<1000; i++) {
         assertEquals(1, Die.roll(0));
      }
   }
   
   // if an invalid value, always roll 1
   public void testStaticRollNegative() {
      for (int i=0; i<1000; i++) {
         assertEquals(1, Die.roll(-1));
      }
   }
}

