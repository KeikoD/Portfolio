//Eden Dronoff
import java.util.Scanner;
/**A class that asks the user if they want to roll or hold
*/
public class UserPigPlayer extends PigPlayer{
/**Constructor for UserPigPlayer
*/
   public UserPigPlayer(String name){
      super(name);
   }
   /**Asks the user if they want to roll again
   */
   public boolean isRolling(int turnTotal, int opponentScore){
      System.out.println("Turn Total: " + turnTotal);
      System.out.println("Roll again?");
      Scanner scnr = new Scanner(System.in);
      String answer=scnr.nextLine();
      if (answer.equals("")){  
         return true;   
      }
      else {
         return false;
      }
   }
}