//Eden Dronoff
/** Tests strategy's to find the most efficient one
**/
public class Simulation {
   static boolean verbose;
   /** Runs a game a certain amount of times
   **/
   public static void firstAdvantage(long simulations){
      long tempSimulations=simulations;
      PigPlayer player1= new SimpleHoldPlayer("Player 1");
      PigPlayer player2= new SimpleHoldPlayer("Player 2");
      PigGame game = new PigGame(player1,player2);
      while(simulations > 0){
         game.playGame();
         game.reset();
         simulations=(simulations-1);
      }
      System.out.print((((double)player1.getWinRecord()/tempSimulations)*100)+"%");
   }
   /**Runs a simulation of games  to determine the best hold value
   **/
   public static double comparePlayers(long simulations, PigPlayer first, PigPlayer second){
      PigPlayer player1= first;
      PigPlayer player2= second;
      long tempSimulations=simulations;
      while(simulations > 0){
         if(simulations%2==0){
            PigGame game = new PigGame(player1,player2);
            game.playGame();
            game.reset();
            simulations=(simulations-1);
         }
         else {
            PigGame game = new PigGame(player2,player1);
            game.playGame();
            game.reset();
            simulations=(simulations-1);
         }
      }
      System.out.println((double)player1.getWinRecord()/tempSimulations);
      return player1.getWinRecord()/tempSimulations;
   }
   public static void comparePlayers2(int hold,int endHold,long simulations){
      for(int i=hold;i<endHold;i++){
         PigPlayer player1=new SimpleHoldPlayer("custom",i);
         PigPlayer player2=new SimpleHoldPlayer("Hold 20");
         comparePlayers(simulations,player1,player2);
      }
   }
   //Main method
   public static void main(String[] args){
   PigPlayer player1=new SimpleHoldPlayer("Hold",25);
   PigPlayer player2=new FourTurnsPlayer("Four turns");
      comparePlayers(1000000,player1,player2);
   }
}