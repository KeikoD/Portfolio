//Eden Dronoff
/**An abstract class representing the player's name, current score, and win record
*/
public abstract class PigPlayer {
   private String playerName;
   private int currentScore=0;
   private int gamesWon=0;
   /**Constructor sets the Player name to "Player" w/o input
   */
   public PigPlayer(){
      playerName="Player";
   }
   /**Constructor sets the Player name to an input
   */
   public PigPlayer(String name){
      playerName=name;
   }
   /**Sets the player name
   */
   public void setName(String P1){
      playerName=P1;
   }
   /**Sets the player name
   */
   public String getName(){
      return playerName;
   }
   /*Resets the game by setting the current score to 0
   */
   public void reset(){
      currentScore=0;
   }
   /*Adds the turn total to the player's score. It also increments the number of wins if the player's score is now greater than or equal to the goal
   */
   public void addPoints(int turnTotal){
      currentScore=currentScore+turnTotal;
      if (currentScore>=PigGame.GOAL){
         gamesWon++;
      }
   }
   /*Returns true if this player has won the game, false otherwise
   */
   public boolean won(){
      if (currentScore>=PigGame.GOAL){
         return true;
      }
      else {
         return false;
      }
   }
   /*Returns the player's current score
   */
   public int getScore(){
      return currentScore;
   }
   /*Returns the number of games this player has won
   */
   public int getWinRecord(){
      return gamesWon;
   }
      /*Returns a String with the player's name and score
      */
   public String toString(){
      return playerName + ": " + currentScore;
   }
   /*Returns a String with the player's name and score
   */
   public boolean equals(PigPlayer other){
      if (other.currentScore == this.currentScore && other.playerName.equals(this.playerName) && other.gamesWon == this.gamesWon){   
         return true;
      }
      else {
         return false;
      }
   } 
   /*Helps to code the player's strategy  
   */
   public abstract boolean isRolling(int turnTotal, int opponentScore);
}