//Eden Dronoff
/**Creates a die with a customizable amount of sides
*/
public class Die {
   int sides=0;
   /**Constructor that creates a six-sided die
   */
   public Die() {
      sides=6;
   }
   /** Constructor that creates a die with custom amount of sides
   */
   public Die(int numberOfSides){
      if (numberOfSides>0){
         sides=numberOfSides;
      }
      else {
         sides=6;
      }
   }
   /** Returns the number of sides
   */
   public int getNumberOfSides(){
      return sides;
   }
   /** Rolls the die
   */
   public int rollDie(){
      return (int)(Math.random()*sides) + 1;
   }  
   /** Roles a 6 sided die
   */
   public static int roll(){
      int sides=6;
      return (int)(Math.random()*sides) + 1;
   }
   /** Rolls a custom sided die
   */
   public static int roll(int sides){
      if (sides<1){
         return 1;
      }
      else {
         return (int)(Math.random()*sides) + 1;
      }
   }
}